# Следующий сеанс — CONTROL1.3

22.10.2026. Активный source: CONTROL1.3 поверх07→08→10→11+12 docs; original Drive archives не изменены. Проверить user local branch перед merge.

**Вход:** AGENTS → ARCHITECTURE → CURRENT_STATE → затронутый passport → реальные файлы/SOURCE_INDEX.69 ESM/11 registry/32 generated ports. Не редактировать native-source или generated targets вручную.

**Сделано:** synthetic reproduction старого auto performance watchdog: WebGL→Canvas; измерен synchronous first floor. Performance policy теперь pinned after startup, bounded history32, explicit user/fault fallback остаются. Canvas visible8×8 chunks/LRU32, cached water overlay2.5Hz, scoped release/revision invalidation. Cave13 overlay: connected existing64×64 halls,3 destructible90HP rocks/explicit boxes, structural walls immutable,6 existing AI roles in9 original spawns. Same graphics/combat pipeline, transparent WebGL HUD guard. Player A/TankVisual/archetype/appearance tables/assets неизменны.

**Видео:** все380 frames decoded и просмотрены в шести numbered contact sheets. f1685.600s last normal; f1695.633s first dark; f1956.500s last dark; f1966.533s partial return; f1976.567s flat/brighter branch. UI/HP/shot persist; animation nearly static. Exact original-device trigger и CPU/GPU freeze timing не доказаны: deployed version/GPU/console отсутствуют. Controlled synthetic replay — не natural reproduction на исходном устройстве.

**Свежие gates:** build/check/provenance pass; focused10/10; unchanged control11=16/16, native17/17, actors7/7; full unit76/78 (old SHA pin + obsolete auto-watchdog expectation). Browser16/16 includes actual WASD/F8/inventory/E cave entry/exit/mouse rock damage/drive-through/normal AI kill/restart/cleanup and actual WebGL HUD transparency; resource plateau10textures/90geometries across3 rebuilds. P0 gate8/8 includes60s render-loop stability and context loss. See separate1.3 report/QA for matched perf values, run conditions and limitations; no60FPS/hardware/mobile/long-soak claim.

**Открыто:** field confirmation на user's PC; export IronDungeon.metrics().rendering before/after original symptom + exact build/URL/GPU/console. Physical GPU/mobile/touch, hours-long soak, whole-cave campaign completion, final art approval not qualified. Existing security advisories and historical texture-count pins untouched. One mixed browser combat attempt timed out after prior fight; isolated normal-HP encounter succeeds, not a full uninterrupted campaign proof. Source ZIP не обновляет старый embedded HTML/release — rebuild required (RUNBOOK). Preserve user changes, old renderers, A identity, native weapons, scoped lifecycle; no broad cleanup/refactor.

## Итоговый RC performance gate — не закрыт
Final matched Canvas1280×800 medium/.5,3 пары: RAF median18.4→19.3ms, p9526.7→31.5ms (хуже ~4.9%/~18%); floor buffers47,040,000→34,340,864B. Source содержит bounded viewport composite с256px padding поверх dry/water chunks. Functional gates не равны performance-pass. Не расширять пещеру дальше; следующий приоритет — compositor/CPU profile и устранение steady-state регрессии, затем field confirmation исходного симптома.
