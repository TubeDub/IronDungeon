# CONTROL1.3.1 — фактический ready rebuild

22.10.2026: ready HTML в папке пользователя оставался byte-identical1.1 (MD5e43106b82667e7535b00422fa5dcf3e1), хотя все34 manifest source13 records совпали. Создан новый автономный IRON_DUNGEON_CONTROL_13_1_PLAY.html,build CONTROL1.3.1-20261022-REBUILT; размер51214624,MD5525580833b56c8d164748b2cb5c27795,все11 embedded resources exact. Изменены build identity в src/main.js/title-meta index.html/stale build guard, без новой механики.

Fresh ready-file checks: старый synthetic slow-frame path переключает старый HTML наCanvas, новый90s сохраняетWebGL/scene/green/oneRAF. WebGL10checks пройдены до screenshot-timeout при context-loss; не весь high SW test pass. Отдельный standalone offline Canvas10/10: real input/fire/E/cave rock damage/collider/drive-through/exit/default no-debug/cleanup. Unit76/78 old2red; physicalGPU/60FPS/perf regression не квалифицированы. Все результаты в /home/user/control131/evidence и BUILD_REPORT_RU.md. Готовый файл наDrive1PxwErAXkU5xDW6TIofWsOpr1eiijertq, не source-only patch.

## Предыдущая1.3 RC — история и ограничения

# Текущее состояние — CONTROL1.3

Source phase1.3, 22.10.2026. Public API foundation-0.1/package0.1.0 intentionally unchanged; mode policy version1.3.69 ESM/11 registry/32 generated ports. Previous1.2 docs stage completed, current task explicitly allowed stability + cave changes.

## Реализовано
- Startup selector retained; after startup slow frames issue a latched warning, never silently swap appearance/backend. Manual renderer selection and genuine context-loss/render-error safety fallback retained. Scoped/bounded telemetry exposed by IronDungeon.metrics().rendering.
- Canvas dry floor8×8 chunks/LRU32 and optional water overlays refreshed only at animation phase changes, not whole-world triple buffers. Original floor images/materials reused; invalidation by map/revision; resize-independent bounded cache.
- Cave13 marks existing cave data in CONTROL gameplay. Seven local corridor/shortcut carves in64×64, original entry/exit/spawn positions;3 explicit rock boxes with90HP; structural CAVE_WALL Infinity; decorative rockDetail nonblocking. Existing swept projectiles/destructible states/collider removal/LOS/movement, no second AI/renderer.
- Nine spawns use existing six role tables without modifying stats/visual tables; current TankVisual/player A/weapons and unrelated assets remain protected. Same Canvas/WebGL engine routes cave; transparent HUD guard prevents invisible but rendered WebGL world.

## Свежая проверка
- npm build/check pass (69/11/32); full npm test **76/78, exit1**. Old source SHA pin inherited; old control07 watchdog assertion expects behavior deliberately forbidden1.3. Neither test changed. Focused13=10/10; unchanged11=16/16; native17/17; actors7/7.
- Browser16/16: real WASD/mouse fire/rock damage/opened route/enemy kill/F8/inventory/E cave+exit/restart/dispose; WebGL all10 tank models and transparent HUD. Three rebuilds plateau10 textures/90 geometries; page errors none. Fixtures place actors/camera near targets, no invulnerability or disabled AI; not full campaign traversal.
- P0 gate8/8:60s real RAF session after synthetic old slow-frame trigger keeps backend/scene/player identity, one RAF owner; manual switching, genuine context loss and scoped cleanup pass. Can include player death; this is not60s uninterrupted combat qualification.
- Matched sequential1280×800 Canvas/medium/.5, three pairs: see separate CONTROL1.3 report/perf13.json for actual measurements. Framebuffer readback/screenshots excluded. No guaranteed60FPS or hardware/mobile qualification.

## Диагноз: доказательства и границы
Video380frames (30FPS,12.667s); f169–195 dark world, persistent HP/HUD/shot, then f196 partial/f197 changed flat-brighter style. All numbered frames reviewed, not endpoints only. This alone does not identify deployed branch/context-loss/CPU trigger.
Controlled **synthetic** old watchdog replay confirmed automatic backend switch and cold Canvas ground283.2ms/whole Canvas462.5ms in original baseline sandbox, not user's original device. Other longtasks/screenshot stalls cannot all be attributed to fallback. Original-device root trigger unknown; useful metrics retained for field evidence.

## Ограничения
Physical GPU/mobile/touch and hours-long soak not tested. Natural old-device reproduction not obtained. Cave art final approval and full uninterrupted nine-enemy campaign not claimed; existing local steering is not new global pathfinding. Npm advisories1moderate+1high and historical texture pins untouched. Canvas is approximation, not true3D/PBR. Native mutable ID/prototype hooks/audio/HUD cross-calls remain existing technical debt.
Source-only patch requires rebuilding release/embedded HTML; not running old standalone. Original remote archives unchanged.

## Итоговый RC performance gate — не закрыт
Final matched Canvas1280×800 medium/.5,3 пары: RAF median18.4→19.3ms, p9526.7→31.5ms (хуже ~4.9%/~18%); floor buffers47,040,000→34,340,864B. Source содержит bounded viewport composite с256px padding поверх dry/water chunks. Functional gates не равны performance-pass. Не расширять пещеру дальше; следующий приоритет — compositor/CPU profile и устранение steady-state регрессии, затем field confirmation исходного симптома.
