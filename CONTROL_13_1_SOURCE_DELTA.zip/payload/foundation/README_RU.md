# CONTROL1.3.1 — готовая пересборка

Готовая игра распространяется отдельным PLAY.html/START.html: Node/npm игроку не нужны. Номер сборки `IronDungeon.build=CONTROL1.3.1-20261022-REBUILT`, title1.3.1. В папке пользователя старый standalone1.1 не был обновлён source overlay; этот rebuild исправляет комплектность. Developer source delta содержит только identity/build guard и память; подробности CURRENT_STATE/NEXT_SESSION. Унаследованные2red/performance/physicalGPU ограничения остаются.

# IRON DUNGEON — CONTROL1.3 / стабильность и пещера

Активный исходный проект: JavaScript ES modules, Vite, Canvas2D и optional local Three r160 WebGL. CONTROL1.3 фиксирует performance-induced backend switch, ограничивает floor cache и интегрирует существующую пещеру в общий pipeline. Player A и таблицы ролей сохранены. npm test76/78: старый SHA pin и old auto-watchdog assertion; не выдавать за полностью зелёный набор. Подробные границы — CURRENT_STATE.

## Начать работу
- [Краткая архитектура](docs/architecture/ARCHITECTURE.md)
- [Карта файлов/модулей](docs/architecture/PROJECT_MAP.md) и [зависимости](docs/architecture/DEPENDENCIES.md)
- [Правила разработки](docs/architecture/DEVELOPMENT_RULES.md) и [проверка актуальности](docs/architecture/VERIFY_MEMORY.md)
- [Текущее состояние](docs/architecture/CURRENT_STATE.md) / [NEXT_SESSION](docs/architecture/NEXT_SESSION.md)
- [Команды, тесты, маленькие ZIP и откат](docs/architecture/RUNBOOK.md)
- [Паспорта ключевых систем](docs/architecture/modules/lifecycle.md)

## Запуск
Node 20.20+ / npm; точная проверенная среда указана в CURRENT_STATE. Из этой папки:

```sh
npm ci
npm run check
npm test                 # в текущей RC ожидается 76/78, exit 1; причина в CURRENT_STATE
npm run dev              # development, не публичный production deployment
# либо production:
npm run build
npm run preview
# автономный HTML:
npm run build:single
```

По реальному GraphicsModeConfig.read defaults: room=control, view=combat, renderer=auto, quality=high. Software/unknown adapter обычно выбирает Canvas. Manual проверки: ?renderer=canvas или ?renderer=webgl; quality=low|medium|high|auto, scale=.5..1. NoThree=1 использовать как `?noThree=1`; diagnostics=1/F8 — графическая панель. Стандартные WASD/мышь/Escape/I/M/E/Q/1 сохранены; точные handlers смотреть в native input/session/UI, не менять в документационной задаче.

`IRON_DUNGEON_FOUNDATION.html` в 1.1 — 51 204 381 bytes, 11 embedded resources. Это готовый артефакт, не source-of-truth; build-single может изменить его при будущей разработке. `release/` обновляется только сборкой. Загрузка сохранения localStorage зависит от origin/file/iframe; HTTP предпочтителен.

Production API: frozen window.IronDungeon с ready/state/metrics/restart/dispose; private mutable ID не public. Только ?compat=1 включает старые тестовые ID/IDGAME/THREE; после dispose они удаляются. Native presentation cross-calls/hook adapters сохранены — это не полная event-only/ECS-перепись.

Исторические migration документы: [MIGRATION_MAP_RU.md](docs/MIGRATION_MAP_RU.md) и starter/brief в docs. Их старые планы/запреты не заменяют актуальную карту. Рабочий rollback для конкретного ZIP должен следовать его manifest/install инструкции; старый scripts/rollback.py восстанавливает pre-foundation только при наличии соответствующих checkpoint ZIP/manifest, это не откат 1.1/1.2.

## CONTROL1.3 source patch
После merge-copy пересобрать release (`npm run build`) или автономный файл (`npm run build:single`). Старый HTML остаётся старой версией до пересборки;51MB embedded artifact не дублируется в небольшом source ZIP. Падение FPS теперь вызывает bounded warning, не автоматическую смену стиля; реальные render failure/context-loss fallback остаются.
